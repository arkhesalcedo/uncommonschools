<?php get_header(); ?>

<ucs-banner 
    page="<?php the_ID(); ?>" 
    read-more-image="<?php echo get_template_directory_uri(); ?>/assets/images/read-more.png"
></ucs-banner>

<ucs-3-blocks-across
    page="<?php the_ID(); ?>" 
    image-link="<?php echo get_template_directory_uri(); ?>/assets/images/arrow-right-yellow.png"
></ucs-3-blocks-across>

<ucs-cta 
    page="<?php the_ID(); ?>" 
    learn-more-image="<?php echo get_template_directory_uri(); ?>/assets/images/learn-more.png"
></ucs-cta>

<?php get_footer(); ?>  