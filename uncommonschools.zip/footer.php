			<ucs-footer
  				image="<?php echo get_template_directory_uri(); ?>/assets/images/footer-bg.jpg" 
  				image-button="<?php echo get_template_directory_uri(); ?>/assets/images/arrow-right.png" 
  				image-link="<?php echo get_template_directory_uri(); ?>/assets/images/arrow-right-yellow.png"
  			></ucs-footer>
  		</div>

  		<script defer src="https://use.fontawesome.com/releases/v5.0.4/js/all.js"></script>
  		<script src="<?php echo get_template_directory_uri(); ?>/app.js"></script>
  </body>
</html>